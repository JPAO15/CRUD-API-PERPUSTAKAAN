<?php
$dbserver = 'localhost';
$dbname = 'id19117212_uaspweb';
$dbuser = 'id19117212_uaspweb2022';
$dbpassword = 'd3IJN0LI6FkS_&HC';
$dsn = "mysql:host={$dbserver};dbname={$dbname}";

$connection = null;
try{
    $connection = new pdo ($dsn, $dbuser, $dbpassword);

} catch (exception $exception) {
    die ("Terjadi Error:".$exception->getMessage());

}
