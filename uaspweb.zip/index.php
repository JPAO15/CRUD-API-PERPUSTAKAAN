<!DOCTYPE html>
<html>
<head>
<title>Perpustakaan</title>
<link rel="stylesheet" href="style.css" />
</head>
    <body>
        <table border="1" width="50%">
            <tr> <th>No</th><th>Data</th> <th>Action</th>
            <tr> <td>1</td><td>Buku</td> <td><a href="http://localhost/uaspweb/buku/all.php" target="_blank"><button>klik</button></a></td> 
            <tr> <td>2</td><td>Anggota</td> <td><a href="http://localhost/uaspweb/anggota/all.php" target="_blank"><button>klik</button></a></td>  
            <tr> <td>3</td><td>Peminjaman</td> <td><a href="http://localhost/uaspweb/peminjaman/all.php" target="_blank"><button>klik</button></a></td>  
            
        </table>
    <div>
    </div>
    </body>
    
</html>